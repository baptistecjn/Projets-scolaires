<?php
//Paramètres de connexion à la base de données
define('SERVEUR', 'localhost');         //hote
define('USER', 'root');                 //login, par exemple "root" ou ""
define('PWD', 'root');                  //mot de passe, par exemple "root" ou ""
define('DB_NAME', 'nomBaseDeDonnees');  //nom de la base de données
?>