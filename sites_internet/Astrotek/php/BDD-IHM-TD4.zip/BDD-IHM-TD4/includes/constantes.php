<?php 
//constante du site, par exemple :
$titreSite = "TD4 BDD-IHM";
?>