#include "vecteur.h"

#include <iostream>

/** \brief Programme principal */
int main()
{
  /** Insérez votre code ici... */
  // std::cout << "--Creez votre vecteur 1--" << std::endl;
  // Vecteur* v1 = lireVecteur();
  // afficherVecteur(v1);

  // std::cout << "--Creez votre vecteur 2--" << std::endl;
  // Vecteur* v2 = lireVecteur();

  // Vecteur* v3 = new Vecteur(*v1 + *v2);
  
  // Vecteur* v4 = new Vecteur(*v1 + *v2 + *v3);

  // Vecteur* v5 = new Vecteur(*v1 * *v2);


    // // Création et affichage d'un vecteur
    // Vecteur v1(3, 1.5);
    // std::cout << "Vecteur v1 : " << v1 << std::endl;

    // // Lecture d'un vecteur
    // Vecteur v2(3); // Crée un vecteur de taille 3 avec des 0
    // std::cout << "Entrez 3 valeurs pour le vecteur v2 : ";
    // std::cin >> v2;

    // // Affichage après saisie
    // std::cout << "Vecteur v2 : " << v2 << std::endl;






  // int index;
  // float nouvelleCo;
  
  // std::cout << "index de la coordonnée à modifier pour v1 : ";
  // std::cin >> index;
  
  // std::cout << "nouvelle coordonnée pour v1 : ";
  // std::cin >> nouvelleCo;

  // v1->set(index, nouvelleCo);

  // std::cout << "Vecteur après modification :" << std::endl;
  // afficherVecteur(v1);

  // std::cout << "--Somme des deux vecteurs--" << std::endl;
  // Vecteur vadd = add(v1,v2);
  // afficherVecteur(&vadd);

  // delete v1;
  // delete v2;
  // delete v3;
  // delete v4;
  // delete v5;



}
